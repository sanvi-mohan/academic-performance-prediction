/**
 * Student Academic Performance Prediction Form - Interactive Logic
 * Handles Dual-Control Sync, Real-time Validation, Dynamic Progress Bar & Presets
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Dual-Control Synced Inputs (Slider <-> Number Box)
    const dualInputs = [
        { slider: 'previous_grade_slider', number: 'previous_grade', min: 0, max: 100, errorId: 'previous_grade_error' },
        { slider: 'internal_marks_slider', number: 'internal_marks', min: 0, max: 100, errorId: 'internal_marks_error' },
        { slider: 'attendance_slider', number: 'attendance_percentage', min: 0, max: 100, errorId: 'attendance_error' },
        { slider: 'assignments_slider', number: 'assignments_completed_pct', min: 0, max: 100, errorId: 'assignments_error' },
        { slider: 'daily_study_slider', number: 'daily_study_hours', min: 0, max: 16, errorId: 'daily_study_error' },
        { slider: 'weekly_study_slider', number: 'study_hours_per_week', min: 0, max: 80, errorId: 'weekly_study_error' },
        { slider: 'social_media_slider', number: 'social_media_hours', min: 0, max: 14, errorId: 'social_media_error' },
        { slider: 'sleep_hours_slider', number: 'sleep_hours', min: 3, max: 12, errorId: 'sleep_hours_error' },
        { slider: 'study_sessions_slider', number: 'study_sessions_per_week', min: 1, max: 14, errorId: 'study_sessions_error' },
        { slider: 'stress_slider', number: 'stress_level', min: 1, max: 10, errorId: 'stress_error' }
    ];

    dualInputs.forEach(item => {
        const sliderEl = document.getElementById(item.slider);
        const numberEl = document.getElementById(item.number);
        const errorEl = document.getElementById(item.errorId);

        if (sliderEl && numberEl) {
            // Slider changes -> Update Number input
            sliderEl.addEventListener('input', () => {
                numberEl.value = sliderEl.value;
                validateField(numberEl, item.min, item.max, errorEl);
                updateFormProgress();
            });

            // Number input changes -> Update Slider input
            numberEl.addEventListener('input', () => {
                const val = parseFloat(numberEl.value);
                if (!isNaN(val) && val >= item.min && val <= item.max) {
                    sliderEl.value = val;
                }
                validateField(numberEl, item.min, item.max, errorEl);
                updateFormProgress();
            });

            // Initial sync & validation
            sliderEl.value = numberEl.value;
        }
    });

    // 2. Real-time Field Validator
    function validateField(inputEl, min, max, errorEl) {
        if (!inputEl) return true;
        const rawVal = inputEl.value.trim();
        const val = parseFloat(rawVal);

        let isValid = true;
        let errorMsg = '';

        if (rawVal === '' || isNaN(val)) {
            isValid = false;
            errorMsg = 'This value is required and must be a valid number.';
        } else if (val < min) {
            isValid = false;
            errorMsg = `Value cannot be less than ${min}.`;
        } else if (val > max) {
            isValid = false;
            errorMsg = `Impossible value: Maximum allowed is ${max}.`;
        }

        if (!isValid) {
            inputEl.classList.add('input-invalid');
            inputEl.classList.remove('input-valid');
            if (errorEl) {
                errorEl.textContent = errorMsg;
                errorEl.classList.add('visible');
            }
        } else {
            inputEl.classList.remove('input-invalid');
            inputEl.classList.add('input-valid');
            if (errorEl) {
                errorEl.textContent = '';
                errorEl.classList.remove('visible');
            }
        }
        return isValid;
    }

    // Number of subjects validation
    const subjectsInput = document.getElementById('num_subjects');
    const subjectsError = document.getElementById('num_subjects_error');
    if (subjectsInput) {
        subjectsInput.addEventListener('input', () => {
            validateField(subjectsInput, 1, 15, subjectsError);
            updateFormProgress();
        });
    }

    // Student Name & ID validation
    const nameInput = document.getElementById('student_name');
    const idInput = document.getElementById('student_id');
    const nameError = document.getElementById('student_name_error');
    const idError = document.getElementById('student_id_error');

    if (nameInput) {
        nameInput.addEventListener('input', () => {
            if (nameInput.value.trim().length >= 2) {
                nameInput.classList.remove('input-invalid');
                nameInput.classList.add('input-valid');
                if (nameError) nameError.classList.remove('visible');
            } else {
                nameInput.classList.add('input-invalid');
                if (nameError) {
                    nameError.textContent = 'Please enter student full name (min 2 characters).';
                    nameError.classList.add('visible');
                }
            }
            updateFormProgress();
        });
    }

    if (idInput) {
        idInput.addEventListener('input', () => {
            if (idInput.value.trim().length >= 2) {
                idInput.classList.remove('input-invalid');
                idInput.classList.add('input-valid');
                if (idError) idError.classList.remove('visible');
            } else {
                idInput.classList.add('input-invalid');
                if (idError) {
                    idError.textContent = 'Please enter a valid student enrollment ID.';
                    idError.classList.add('visible');
                }
            }
            updateFormProgress();
        });
    }

    // 3. Dynamic Progress Bar Calculation
    const progressFill = document.getElementById('formProgressFill');
    const progressBadge = document.getElementById('formProgressPct');
    const step1El = document.getElementById('stepIndicator1');
    const step2El = document.getElementById('stepIndicator2');
    const step3El = document.getElementById('stepIndicator3');
    const step4El = document.getElementById('stepIndicator4');

    function updateFormProgress() {
        let totalScore = 0;

        // Section 1: Personal (25 pts)
        const nameValid = nameInput && nameInput.value.trim().length >= 2;
        const idValid = idInput && idInput.value.trim().length >= 2;
        if (nameValid && idValid) {
            totalScore += 25;
            if (step1El) { step1El.classList.add('completed'); step1El.classList.remove('active'); }
        } else if (nameValid || idValid) {
            totalScore += 12;
            if (step1El) step1El.classList.add('active');
        }

        // Section 2: Academic Info (25 pts)
        const attVal = parseFloat(document.getElementById('attendance_percentage')?.value || 0);
        const prevVal = parseFloat(document.getElementById('previous_grade')?.value || 0);
        const intVal = parseFloat(document.getElementById('internal_marks')?.value || 0);
        if (attVal > 0 && attVal <= 100 && prevVal > 0 && prevVal <= 100 && intVal > 0 && intVal <= 100) {
            totalScore += 25;
            if (step2El) { step2El.classList.add('completed'); step2El.classList.remove('active'); }
        } else {
            totalScore += 10;
            if (step2El) step2El.classList.add('active');
        }

        // Section 3: Study Habits (25 pts)
        const dailyVal = parseFloat(document.getElementById('daily_study_hours')?.value || 0);
        const sleepVal = parseFloat(document.getElementById('sleep_hours')?.value || 0);
        if (dailyVal > 0 && sleepVal >= 3) {
            totalScore += 25;
            if (step3El) { step3El.classList.add('completed'); step3El.classList.remove('active'); }
        } else {
            totalScore += 10;
            if (step3El) step3El.classList.add('active');
        }

        // Section 4: Additional Factors (25 pts)
        totalScore += 25;
        if (step4El) { step4El.classList.add('completed'); }

        const finalPct = Math.min(100, Math.max(15, totalScore));

        if (progressFill) progressFill.style.width = finalPct + '%';
        if (progressBadge) progressBadge.textContent = finalPct + '% Completed';
    }

    // Auto-calculate weekly study from daily × sessions
    window.autoCalculateWeekly = function() {
        const daily = parseFloat(document.getElementById('daily_study_hours')?.value || 2.5);
        const sessions = parseInt(document.getElementById('study_sessions_per_week')?.value || 5);
        const calculatedWeekly = Math.min(80, Math.round(daily * sessions * 10) / 10);

        const weeklyNumber = document.getElementById('study_hours_per_week');
        const weeklySlider = document.getElementById('weekly_study_slider');

        if (weeklyNumber && weeklySlider) {
            weeklyNumber.value = calculatedWeekly;
            weeklySlider.value = calculatedWeekly;
            weeklyNumber.dispatchEvent(new Event('input'));
        }
    };

    // 4. One-Click Preset Profiles
    const presets = {
        top: {
            student_name: 'Aarav Sharma',
            student_id: 'STU-2024-101',
            current_semester: 'Semester 5',
            department: 'Computer Science & AI',
            previous_grade: 89.5,
            internal_marks: 92.0,
            assignments_completed_pct: 98.0,
            attendance_percentage: 95.5,
            num_subjects: 6,
            daily_study_hours: 3.5,
            study_hours_per_week: 22.0,
            social_media_hours: 1.2,
            sleep_hours: 7.5,
            study_sessions_per_week: 6,
            extracurricular_hours: 4.0,
            attends_coaching: 'No - Pure Self Study',
            academic_confidence: 'Very High',
            stress_level: 3,
            parental_involvement: 'High',
            internet_access: 'Yes'
        },
        average: {
            student_name: 'Priya Patel',
            student_id: 'STU-2024-102',
            current_semester: 'Semester 4',
            department: 'Electronics & Communication',
            previous_grade: 74.0,
            internal_marks: 72.5,
            assignments_completed_pct: 82.0,
            attendance_percentage: 84.0,
            num_subjects: 6,
            daily_study_hours: 2.2,
            study_hours_per_week: 14.0,
            social_media_hours: 2.5,
            sleep_hours: 7.0,
            study_sessions_per_week: 5,
            extracurricular_hours: 5.0,
            attends_coaching: 'Occasional Doubt Sessions',
            academic_confidence: 'Moderate',
            stress_level: 5,
            parental_involvement: 'Medium',
            internet_access: 'Yes'
        },
        risk: {
            student_name: 'Rohan Verma',
            student_id: 'STU-2024-103',
            current_semester: 'Semester 6',
            department: 'Information Technology',
            previous_grade: 54.0,
            internal_marks: 49.0,
            assignments_completed_pct: 58.0,
            attendance_percentage: 66.0,
            num_subjects: 7,
            daily_study_hours: 1.0,
            study_hours_per_week: 6.5,
            social_media_hours: 5.0,
            sleep_hours: 5.0,
            study_sessions_per_week: 2,
            extracurricular_hours: 14.0,
            attends_coaching: 'No - Pure Self Study',
            academic_confidence: 'Low',
            stress_level: 9,
            parental_involvement: 'Low',
            internet_access: 'Yes'
        }
    };

    window.applyPreset = function(type) {
        const data = presets[type];
        if (!data) return;

        for (const [key, val] of Object.entries(data)) {
            const el = document.getElementById(key);
            if (el) {
                el.value = val;
                // Dispatch input event to sync sliders and validation
                el.dispatchEvent(new Event('input'));
            }
        }
        updateFormProgress();
    };

    // 5. Form Submission Verification
    const form = document.getElementById('predictionForm');
    const submitBtn = document.getElementById('submitBtn');

    if (form && submitBtn) {
        form.addEventListener('submit', (e) => {
            // Check all dual controls for impossible values
            let hasError = false;
            let firstInvalidEl = null;

            dualInputs.forEach(item => {
                const numberEl = document.getElementById(item.number);
                const errorEl = document.getElementById(item.errorId);
                if (numberEl) {
                    const valid = validateField(numberEl, item.min, item.max, errorEl);
                    if (!valid && !hasError) {
                        hasError = true;
                        firstInvalidEl = numberEl;
                    }
                }
            });

            // Check name and ID
            if (!nameInput || nameInput.value.trim().length < 2) {
                hasError = true;
                if (!firstInvalidEl) firstInvalidEl = nameInput;
                if (nameError) {
                    nameError.textContent = 'Please enter student full name.';
                    nameError.classList.add('visible');
                }
            }

            if (!idInput || idInput.value.trim().length < 2) {
                hasError = true;
                if (!firstInvalidEl) firstInvalidEl = idInput;
                if (idError) {
                    idError.textContent = 'Please enter a valid student enrollment ID.';
                    idError.classList.add('visible');
                }
            }

            if (hasError) {
                e.preventDefault();
                if (firstInvalidEl) {
                    firstInvalidEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstInvalidEl.focus();
                }
                return false;
            }

            // Animate submit button
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing Neural Weights...';
        });
    }

    // Initial progress computation
    updateFormProgress();
});
