/**
 * Dashboard & Result Page Charts & Dynamic Filters
 */

// Filter dashboard table by student name/ID and risk level
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('tableSearch');
    const filterSelect = document.getElementById('riskFilter');
    const tableBody = document.getElementById('predictionsTableBody');

    if (searchInput && tableBody) {
        function filterRows() {
            const query = searchInput.value.toLowerCase().trim();
            const filterVal = filterSelect ? filterSelect.value : 'all';
            const rows = tableBody.querySelectorAll('tr');

            rows.forEach(row => {
                const nameText = row.querySelector('.col-name')?.textContent.toLowerCase() || '';
                const idText = row.querySelector('.col-id')?.textContent.toLowerCase() || '';
                const riskBadge = row.querySelector('.risk-badge')?.textContent.toLowerCase() || '';

                const matchesQuery = nameText.includes(query) || idText.includes(query);
                const matchesFilter = (filterVal === 'all') || riskBadge.includes(filterVal.toLowerCase());

                if (matchesQuery && matchesFilter) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        searchInput.addEventListener('input', filterRows);
        if (filterSelect) {
            filterSelect.addEventListener('change', filterRows);
        }
    }
});

// Export Dashboard Table Records to CSV
function exportTableToCSV(filename = 'academic_predictions.csv') {
    const table = document.querySelector('.table');
    if (!table) return;

    let csv = [];
    const rows = table.querySelectorAll('tr');

    for (let i = 0; i < rows.length; i++) {
        if (rows[i].style.display === 'none') continue;

        let row = [], cols = rows[i].querySelectorAll('td, th');
        // Exclude the last column (Action column)
        for (let j = 0; j < cols.length - 1; j++) {
            let data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, ' ').replace(/(\s\s+)/gm, ' ');
            data = data.replace(/"/g, '""');
            row.push('"' + data.trim() + '"');
        }
        csv.push(row.join(','));
    }

    const csvFile = new Blob([csv.join('\n')], { type: 'text/csv' });
    const downloadLink = document.createElement('a');
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}

// Render Results Page Charts
function initResultCharts(factorBreakdown) {
    // 1. Radar Chart: Student Profile vs High Performer Benchmark
    const radarCtx = document.getElementById('radarChart');
    if (radarCtx && factorBreakdown) {
        new Chart(radarCtx, {
            type: 'radar',
            data: {
                labels: [
                    'Study Hours', 'Attendance', 'Previous Grade',
                    'Assignments', 'Sleep Health', 'Stress Control', 'Extracurricular'
                ],
                datasets: [
                    {
                        label: 'Student Score Profile',
                        data: [
                            factorBreakdown.study_hours || 70,
                            factorBreakdown.attendance || 75,
                            factorBreakdown.previous_grade || 70,
                            factorBreakdown.assignments || 80,
                            factorBreakdown.sleep_health || 80,
                            factorBreakdown.stress_management || 75,
                            factorBreakdown.extracurricular_balance || 80
                        ],
                        backgroundColor: 'rgba(99, 102, 241, 0.25)',
                        borderColor: '#6366f1',
                        borderWidth: 2,
                        pointBackgroundColor: '#38bdf8',
                        pointBorderColor: '#ffffff',
                        pointHoverRadius: 6
                    },
                    {
                        label: 'Top Performer Benchmark',
                        data: [92, 95, 90, 95, 90, 85, 85],
                        backgroundColor: 'rgba(56, 189, 248, 0.1)',
                        borderColor: 'rgba(56, 189, 248, 0.5)',
                        borderDash: [5, 5],
                        borderWidth: 1.5,
                        pointRadius: 3
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        angleLines: { color: 'rgba(15, 23, 42, 0.08)' },
                        grid: { color: 'rgba(15, 23, 42, 0.08)' },
                        pointLabels: {
                            font: { size: 11, family: 'Inter', weight: 600 },
                            color: '#1e293b'
                        },
                        suggestedMin: 0,
                        suggestedMax: 100
                    }
                },
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { boxWidth: 12, font: { family: 'Inter', size: 12 } }
                    }
                }
            }
        });
    }

    // 2. Horizontal Bar: Key Factor Contributions
    const barCtx = document.getElementById('factorBarChart');
    if (barCtx && factorBreakdown) {
        new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: ['Previous Marks', 'Attendance', 'Study Habits', 'Assignments', 'Sleep & Stress'],
                datasets: [{
                    label: 'Impact Score (out of 100)',
                    data: [
                        factorBreakdown.previous_grade || 70,
                        factorBreakdown.attendance || 75,
                        factorBreakdown.study_hours || 70,
                        factorBreakdown.assignments || 80,
                        ((factorBreakdown.sleep_health + factorBreakdown.stress_management) / 2) || 75
                    ],
                    backgroundColor: [
                        '#0284c7',
                        '#38bdf8',
                        '#6366f1',
                        '#818cf8',
                        '#10b981'
                    ],
                    borderRadius: 8
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        min: 0,
                        max: 100,
                        grid: { color: 'rgba(15, 23, 42, 0.06)' }
                    },
                    y: {
                        grid: { display: false }
                    }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }
}

// Render Dashboard Analytics Charts
function initDashboardCharts(metrics) {
    // 1. Grade Distribution Chart (Doughnut)
    const gradeCtx = document.getElementById('gradeDistChart');
    if (gradeCtx && metrics && metrics.grade_distribution) {
        const dist = metrics.grade_distribution;
        new Chart(gradeCtx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(dist),
                datasets: [{
                    data: Object.values(dist),
                    backgroundColor: [
                        '#10b981', '#38bdf8', '#0284c7', '#6366f1',
                        '#f59e0b', '#f97316', '#ef4444'
                    ],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '68%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { boxWidth: 12, padding: 12, font: { family: 'Inter', size: 12 } }
                    }
                }
            }
        });
    }

    // 2. Risk Level Overview (Bar)
    const riskCtx = document.getElementById('riskDistChart');
    if (riskCtx && metrics) {
        new Chart(riskCtx, {
            type: 'bar',
            data: {
                labels: ['Low Risk (Safe)', 'Moderate Risk (Watch)', 'High Risk (Alert)'],
                datasets: [{
                    label: 'Students Count',
                    data: [metrics.low_risk || 0, metrics.moderate_risk || 0, metrics.high_risk || 0],
                    backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1 },
                        grid: { color: 'rgba(15, 23, 42, 0.06)' }
                    },
                    x: {
                        grid: { display: false }
                    }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }
}
