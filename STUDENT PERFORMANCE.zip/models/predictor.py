"""
=============================================================================
Academic Performance Prediction Engine (Demo Prediction Architecture)
=============================================================================
DISCLAIMER & ARCHITECTURAL NOTE:
This module currently implements an educational data-mining heuristic simulation
(Rule-Based Multi-Variate Scoring Model) clearly labeled as DEMO PREDICTION LOGIC.
It is intentionally decoupled from the Flask frontend routes so that a trained 
Scikit-Learn model (e.g., RandomForestRegressor, GradientBoosting, or LinearRegression) 
or a deep learning pipeline (PyTorch/TensorFlow) can be seamlessly plugged into 
`predict_academic_performance(data)` in subsequent phases.
=============================================================================
"""

def predict_academic_performance(data):
    """
    Computes predicted percentage, performance category ('Excellent', 'Good', 
    'Average', 'Needs Improvement'), personalized academic analysis, identified
    strengths, areas for improvement, and actionable study prescriptions.
    """
    # -------------------------------------------------------------
    # 1. Feature Extraction & Parsing
    # -------------------------------------------------------------
    previous_grade = float(data.get('previous_grade', 75.0))
    internal_marks = float(data.get('internal_marks', previous_grade))
    attendance = float(data.get('attendance_percentage', 85.0))
    assignments = float(data.get('assignments_completed_pct', 80.0))
    num_subjects = int(data.get('num_subjects', 6))
    
    daily_study = float(data.get('daily_study_hours', 2.5))
    study_hours = float(data.get('study_hours_per_week', 15.0))
    social_media = float(data.get('social_media_hours', 2.0))
    sleep_hours = float(data.get('sleep_hours', 7.0))
    study_sessions = int(data.get('study_sessions_per_week', 5))
    
    extracurricular = float(data.get('extracurricular_hours', 4.0))
    coaching = str(data.get('attends_coaching', 'No'))
    confidence = str(data.get('academic_confidence', 'Moderate'))
    stress = int(data.get('stress_level', 5))
    parental = str(data.get('parental_involvement', 'Medium'))
    internet = str(data.get('internet_access', 'Yes'))

    # -------------------------------------------------------------
    # 2. Multi-Variate Heuristic Weight Calculation (Demo Model)
    # -------------------------------------------------------------
    # A. Academic Historical Core (44% total weight)
    past_score = max(0.0, min(100.0, previous_grade))
    internals_score = max(0.0, min(100.0, internal_marks))
    academic_core = (past_score * 0.26) + (internals_score * 0.18)

    # B. Attendance Component (22% total weight + regulatory 75% cutoff penalty)
    attendance_score = max(0.0, min(100.0, attendance))
    att_penalty = (75.0 - attendance) * 0.45 if attendance < 75.0 else 0.0
    attendance_weighted = (attendance_score * 0.22)

    # C. Self-Study Commitment (18% weight with diminishing returns above 25 hrs)
    if study_hours <= 25.0:
        study_score = min(100.0, (study_hours / 25.0) * 100.0)
    else:
        study_score = min(100.0, 100.0 + (study_hours - 25.0) * 0.4)
    session_bonus = min(2.0, (study_sessions / 7.0) * 2.0)
    study_weighted = (study_score * 0.18) + session_bonus

    # D. Assignment & Practical Submission Compliance (14% weight)
    assign_score = max(0.0, min(100.0, assignments))
    assignments_weighted = (assign_score * 0.14)

    # E. Cognitive & Lifestyle Modifiers (+/- offsets)
    # Social media screen-time drag
    if social_media <= 1.5:
        social_modifier = +1.2
        distraction_rating = 95
    elif social_media <= 3.0:
        social_modifier = 0.0
        distraction_rating = 80
    else:
        social_modifier = - (social_media - 3.0) * 1.3
        distraction_rating = max(20, 100 - int(social_media * 12))

    # Sleep modifier (optimal cognitive window: 7.0 - 8.5 hours)
    if 7.0 <= sleep_hours <= 8.5:
        sleep_modifier = +1.5
        sleep_rating = 95
    elif 6.0 <= sleep_hours < 7.0:
        sleep_modifier = 0.0
        sleep_rating = 80
    elif sleep_hours < 6.0:
        sleep_modifier = - (6.0 - sleep_hours) * 1.7
        sleep_rating = max(30, int(sleep_hours * 12))
    else:
        sleep_modifier = - (sleep_hours - 8.5) * 0.7
        sleep_rating = 75

    # Stress modifier (1 to 10 scale)
    if stress <= 3:
        stress_modifier = +1.0
        stress_rating = 90
    elif stress <= 6:
        stress_modifier = 0.0
        stress_rating = 75
    else:
        stress_modifier = - (stress - 6) * 1.3
        stress_rating = max(20, 100 - (stress * 9))

    # Coaching & Mentorship
    if 'Yes' in coaching:
        coaching_modifier = +1.5
    elif 'Occasional' in coaching:
        coaching_modifier = +0.5
    else:
        coaching_modifier = 0.0

    # Self-efficacy / Academic confidence
    conf_map = {'Very High': 2.0, 'High': 1.0, 'Moderate': 0.0, 'Low': -1.5}
    conf_modifier = conf_map.get(confidence, 0.0)

    # Course workload penalty (above 7 active subjects)
    workload_modifier = - (num_subjects - 7) * 0.75 if num_subjects > 7 else 0.0

    # Extracurricular balance
    if 2.0 <= extracurricular <= 8.0:
        extra_modifier = +1.0
    elif extracurricular > 12.0:
        extra_modifier = - (extracurricular - 12.0) * 0.6
    else:
        extra_modifier = 0.0

    # -------------------------------------------------------------
    # 3. Final Score Compilation & Clamping
    # -------------------------------------------------------------
    raw_score = (
        academic_core +
        attendance_weighted +
        study_weighted +
        assignments_weighted +
        sleep_modifier +
        stress_modifier +
        social_modifier +
        coaching_modifier +
        conf_modifier +
        workload_modifier +
        extra_modifier -
        att_penalty
    )

    # Predicted percentage bounded between 18.0% and 99.4%
    predicted_score = round(max(18.0, min(99.4, raw_score)), 1)

    # -------------------------------------------------------------
    # 4. Performance Category Classification (Exact 4 Categories)
    # -------------------------------------------------------------
    if predicted_score >= 85.0:
        performance_category = "Excellent"
        category_color = "#10b981"  # Emerald Green
        category_badge = "excellent"
    elif predicted_score >= 70.0:
        performance_category = "Good"
        category_color = "#0284c7"  # Light/Navy Blue
        category_badge = "good"
    elif predicted_score >= 55.0:
        performance_category = "Average"
        category_color = "#f59e0b"  # Amber
        category_badge = "average"
    else:
        performance_category = "Needs Improvement"
        category_color = "#ef4444"  # Rose Red
        category_badge = "needs-improvement"

    # GPA Calculation (4.0 Scale) and Letter Grade
    if predicted_score >= 90:
        predicted_gpa = round(3.7 + ((predicted_score - 90) / 10.0) * 0.3, 2)
        letter_grade = "A+" if predicted_score >= 94 else "A"
    elif predicted_score >= 80:
        predicted_gpa = round(3.3 + ((predicted_score - 80) / 10.0) * 0.4, 2)
        letter_grade = "A-" if predicted_score >= 85 else "B+"
    elif predicted_score >= 70:
        predicted_gpa = round(2.7 + ((predicted_score - 70) / 10.0) * 0.6, 2)
        letter_grade = "B"
    elif predicted_score >= 60:
        predicted_gpa = round(2.0 + ((predicted_score - 60) / 10.0) * 0.7, 2)
        letter_grade = "C"
    elif predicted_score >= 50:
        predicted_gpa = round(1.0 + ((predicted_score - 50) / 10.0) * 1.0, 2)
        letter_grade = "D"
    else:
        predicted_gpa = round(max(0.0, (predicted_score / 50.0) * 1.0), 2)
        letter_grade = "F"
    predicted_gpa = min(4.0, predicted_gpa)

    # Early Risk Classification
    if predicted_score >= 75.0 and attendance >= 80.0 and stress <= 7:
        risk_level = "Low Risk"
    elif predicted_score >= 55.0 and attendance >= 70.0:
        risk_level = "Moderate Risk"
    else:
        risk_level = "High Risk"

    # Confidence metric for the demo model
    var_penalty = abs(past_score - attendance_score) * 0.04 + abs(past_score - study_score) * 0.04
    confidence_score = round(max(88.0, min(97.0, 96.2 - var_penalty)), 1)

    # -------------------------------------------------------------
    # 5. Personalized Academic Analysis Narrative
    # -------------------------------------------------------------
    score_diff = round(predicted_score - previous_grade, 1)
    trajectory_phrase = (
        f"shows an upward growth trajectory of +{score_diff}% compared to your previous semester ({previous_grade}%)"
        if score_diff > 0
        else (f"indicates a marginal dip of {score_diff}% compared to your prior marks ({previous_grade}%)"
              if score_diff < 0
              else f"remains consistent with your prior baseline marks ({previous_grade}%)")
    )

    analysis_summary = (
        f"Based on your submitted academic and behavioral parameters, the system projects a semester score of "
        f"{predicted_score}% ({letter_grade} grade / {predicted_gpa} GPA), placing your performance in the "
        f"'{performance_category}' category. This projection {trajectory_phrase}. "
        f"The primary driving factor is your current attendance standing of {attendance}% coupled with "
        f"{study_hours} weekly self-study hours across {num_subjects} registered courses. "
        f"Furthermore, a daily sleep routine of {sleep_hours} hours and {social_media} hours of screen distraction "
        f"were computed into your cognitive retention and examination stress buffer."
    )

    # -------------------------------------------------------------
    # 6. Strengths Identified from Student Input
    # -------------------------------------------------------------
    strengths = []
    if attendance >= 85.0:
        strengths.append(f"Excellent Lecture Attendance: At {attendance}%, your class presence is safely above university thresholds, ensuring maximum internal credits and concept continuity.")
    if study_hours >= 16.0:
        strengths.append(f"Strong Study Dedication: Logging {study_hours} weekly self-study hours provides robust foundational mastery across all {num_subjects} subjects.")
    if assignments >= 85.0:
        strengths.append(f"High Assignment Completion: Completing {assignments}% of coursework and labs guarantees continuous assessment stability.")
    if 7.0 <= sleep_hours <= 8.5:
        strengths.append(f"Healthy Circadian Sleep Routine: Averaging {sleep_hours} hours of nightly rest supports optimal synaptic memory consolidation.")
    if social_media <= 2.0:
        strengths.append(f"Disciplined Digital Focus: Restricting social media to {social_media} hrs/day protects deep concentration intervals.")
    if study_sessions >= 5:
        strengths.append(f"Spaced Study Repetition: Distributing your preparation across {study_sessions} weekly sessions prevents exam-night cramming fatigue.")
    if internal_marks >= 80.0:
        strengths.append(f"Solid Continuous Assessment: Internal assessment marks of {internal_marks}% provide a strong scoring cushion.")
    if not strengths:
        strengths.append("Foundational Awareness: You have proactively evaluated your semester metrics early, giving you full leverage to implement corrective action.")

    # -------------------------------------------------------------
    # 7. Areas That Need Improvement
    # -------------------------------------------------------------
    improvements = []
    if attendance < 75.0:
        improvements.append(f"Critical Attendance Deficit: Your attendance ({attendance}%) is below the mandatory 75% college cutoff, placing you at immediate risk of exam debarment.")
    elif attendance < 82.0:
        improvements.append(f"Sub-Optimal Attendance: At {attendance}%, you are missing approximately 1 out of every 5 lectures, leading to key conceptual gaps.")
    if study_hours < 12.0:
        improvements.append(f"Insufficient Self-Study Volume: Dedicated self-study ({study_hours} hrs/week) is light for a course load of {num_subjects} subjects.")
    if social_media > 3.0:
        improvements.append(f"High Digital Distraction: Spending {social_media} hours daily on social media displaces valuable revision time and fragments cognitive focus.")
    if sleep_hours < 6.0:
        improvements.append(f"Chronic Sleep Deprivation: Sleeping only {sleep_hours} hours/night significantly reduces memory recall and cognitive processing speed.")
    if stress >= 7:
        improvements.append(f"Elevated Academic Stress: High stress rating ({stress}/10) can trigger exam anxiety and impede performance under timed conditions.")
    if internal_marks < 60.0:
        improvements.append(f"Weak Internal Exam Scores: Internal assessments ({internal_marks}%) reflect difficulties with formative semester testing.")
    if not improvements:
        improvements.append("Refinement of Advanced Topics: Continue challenging yourself with capstone research papers and competitive problem solving.")

    # -------------------------------------------------------------
    # 8. Actionable Personalized Study Recommendations
    # -------------------------------------------------------------
    recommendations = []
    if attendance < 75.0:
        recommendations.append("Priority Attendance Recovery: Attend 100% of all upcoming scheduled classes and labs to pull your attendance above the 75% regulatory barrier.")
    elif attendance < 88.0:
        recommendations.append("Attendance Upgrade: Boosting attendance to 90%+ is estimated to lift internal assessment marks by an immediate 3.5% to 5.0%.")

    if study_hours < 18.0:
        needed_hrs = round(max(4.0, 18.0 - study_hours), 1)
        recommendations.append(f"Study Time Expansion: Increase self-study by approximately +{needed_hrs} hrs/week (about 45 mins/day) to transition toward the 'Excellent' category.")

    if social_media > 2.5:
        recommendations.append(f"Implement Screen-Time Boundaries: Cap social media usage to under 1.5 hours/day using phone focus modes or app timers during prime study slots.")

    if sleep_hours < 7.0:
        recommendations.append("Sleep Hygiene Optimization: Commit to a consistent 7.0+ hour nightly sleep schedule, especially in the 14 days preceding examinations.")

    if study_sessions < 5:
        recommendations.append("Adopt Pomodoro / Spaced Intervals: Break your study schedule into 5 to 6 dedicated 50-minute blocks throughout the week rather than marathon cramming.")

    if 'Yes' not in coaching and (previous_grade < 65.0 or internal_marks < 60.0):
        recommendations.append("Departmental Peer Tutoring: Attend weekly faculty doubt-clearing hours or form a peer study circle for your most challenging subjects.")

    # -------------------------------------------------------------
    # 9. Factor Breakdown for Visualizations
    # -------------------------------------------------------------
    factor_breakdown = {
        "study_hours": round(min(100.0, study_score), 1),
        "attendance": round(attendance_score, 1),
        "previous_grade": round(past_score, 1),
        "assignments": round(assign_score, 1),
        "sleep_health": round(sleep_rating, 1),
        "stress_management": round(stress_rating, 1),
        "social_focus": round(distraction_rating, 1)
    }

    return {
        "predicted_score": predicted_score,
        "performance_category": performance_category,
        "category_badge": category_badge,
        "category_color": category_color,
        "predicted_gpa": predicted_gpa,
        "predicted_grade_letter": letter_grade,
        "risk_level": risk_level,
        "confidence_score": confidence_score,
        "analysis_summary": analysis_summary,
        "strengths": strengths,
        "improvements": improvements,
        "recommendations": recommendations,
        "factor_breakdown": factor_breakdown
    }
